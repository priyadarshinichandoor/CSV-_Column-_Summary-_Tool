# CSV Column Summary Tool (v2.0)

A local Python tool that profiles CSV files in a single streaming pass with bounded memory. Standard library only (matplotlib optional for charts).

## Quick start
```
python main.py                       # interactive menu
python main.py sample_data.csv       # one-shot analysis
python main.py data.csv -o report.html --force --no-history
python -m unittest discover -s . -t .   # 40 automated tests
```

## Features
- Per column: type, missing count and %, unique count, top-5 values, min / Q1 / median / mean / Q3 / max / std-dev
- **Outlier detection** (IQR rule) and a **data-quality score** per file
- Streaming parse: 1,000,000 rows (21 MB) profiled in ~7 s using ~48 MB RAM; reservoir-sampled median/quartiles flagged when approximate; Welford's algorithm keeps mean/std exact
- Exports: `.md`, `.txt`, `.csv`, `.json`, `.html`
- Searchable local history (filename / column / type), capped at 500 records, atomic writes, corrupt files preserved as `.corrupt`
- Optional histogram with mean/median markers

## Security
- Rejects symlinks, non-.csv inputs, files over 2 GiB, non-UTF-8 data
- Export path validation (allowed extensions only, no folders/symlinks, asks before overwriting)
- Spreadsheet formula-injection protection in exported text (`=`, `+`, `-`, `@`)
- HTML export is escaped; nothing is uploaded; no network access

## Layout
```
main.py              entry point
csvsummary/profiler.py   streaming statistics (no I/O to the user)
csvsummary/storage.py    atomic writes, history, search
csvsummary/exporters.py  report formats + safety
csvsummary/charts.py     optional histogram
csvsummary/cli.py        argparse + menu UI
tests/                   40 unit tests
```
Design: profiling, storage, export and UI are separate layers, so the business logic is testable without any console I/O.
