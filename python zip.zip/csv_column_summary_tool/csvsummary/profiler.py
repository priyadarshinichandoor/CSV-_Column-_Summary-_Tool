"""Streaming CSV profiler: one pass, bounded memory, no third-party dependencies."""
from __future__ import annotations

import csv
import math
import random
import statistics
from datetime import datetime, timezone
from pathlib import Path

MEDIAN_SAMPLE_LIMIT = 20_000
UNIQUE_LIMIT = 100_000
TOP_VALUES = 5
MAX_FILE_BYTES = 2 * 1024**3  # 2 GiB safety cap


class ProfileError(ValueError):
    """Raised for any user-correctable problem with the input file."""


class _Column:
    """Accumulator for a single column (Welford's algorithm for mean/variance)."""

    def __init__(self, sample_limit: int, rng: random.Random):
        self.missing = self.non_empty = self.count = 0
        self.unique: set[str] = set()
        self.freq: dict[str, int] = {}
        self.numeric = True
        self.min = self.max = None
        self.mean = self.m2 = 0.0
        self.sample: list[float] = []
        self.limit, self.rng = sample_limit, rng

    def add(self, raw: str) -> None:
        value = raw.strip()
        if not value:
            self.missing += 1
            return
        self.non_empty += 1
        if len(self.unique) <= UNIQUE_LIMIT:
            self.unique.add(value)
        if value in self.freq or len(self.freq) < UNIQUE_LIMIT:
            self.freq[value] = self.freq.get(value, 0) + 1
        if not self.numeric:
            return
        try:
            number = float(value)
            if not math.isfinite(number):
                raise ValueError
        except ValueError:
            self.numeric = False
            self.sample.clear()
            return
        self.count += 1
        delta = number - self.mean
        self.mean += delta / self.count
        self.m2 += delta * (number - self.mean)
        self.min = number if self.min is None else min(self.min, number)
        self.max = number if self.max is None else max(self.max, number)
        if len(self.sample) < self.limit:
            self.sample.append(number)
        else:  # reservoir sampling keeps memory bounded
            j = self.rng.randrange(self.count)
            if j < self.limit:
                self.sample[j] = number

    def summary(self, name: str, rows: int) -> dict:
        is_numeric = self.numeric and self.count > 0
        out = {
            "name": name,
            "type": "numeric" if is_numeric else "text",
            "missing": self.missing,
            "missing_pct": round(100 * self.missing / rows, 2) if rows else 0.0,
            "non_empty": self.non_empty,
            "unique": len(self.unique),
            "unique_is_lower_bound": len(self.unique) > UNIQUE_LIMIT,
            "top_values": [[v, c] for v, c in sorted(
                self.freq.items(), key=lambda kv: (-kv[1], kv[0]))[:TOP_VALUES]],
        }
        if is_numeric:
            std = math.sqrt(self.m2 / (self.count - 1)) if self.count > 1 else 0.0
            q1, q2, q3 = (statistics.quantiles(self.sample, n=4, method="inclusive")
                          if len(self.sample) > 1 else [self.sample[0]] * 3)
            iqr = q3 - q1
            lo, hi = q1 - 1.5 * iqr, q3 + 1.5 * iqr
            out.update(
                min=self.min, max=self.max, mean=self.mean, median=q2, std=std,
                q1=q1, q3=q3,
                outliers=sum(1 for x in self.sample if x < lo or x > hi),
                median_is_sampled=self.count > self.limit,
            )
        return out


def quality_score(columns: list[dict]) -> float:
    """0-100 completeness score: share of non-missing cells."""
    if not columns:
        return 100.0
    return round(100 - sum(c["missing_pct"] for c in columns) / len(columns), 1)


def profile_csv(path, median_limit: int = MEDIAN_SAMPLE_LIMIT, seed: int | None = 42) -> dict:
    """Profile a CSV in one streaming pass. Median/quartiles are exact up to median_limit values."""
    source = Path(path).expanduser()
    if source.is_symlink():
        raise ProfileError("Symbolic links are not accepted; pass the real file path.")
    if not source.is_file():
        raise FileNotFoundError(f"File not found: {source}")
    if source.suffix.lower() != ".csv":
        raise ProfileError("Please choose a .csv file.")
    if median_limit < 1:
        raise ProfileError("median_limit must be positive.")
    if source.stat().st_size > MAX_FILE_BYTES:
        raise ProfileError("File is larger than the 2 GiB safety limit.")

    rng = random.Random(seed)
    reader = None
    try:
        with source.open("r", encoding="utf-8-sig", newline="") as stream:
            reader = csv.reader(stream, strict=True)
            try:
                headers = [h.strip() for h in next(reader)]
            except StopIteration:
                raise ProfileError("CSV is empty; add a header row.") from None
            if any(not h for h in headers):
                raise ProfileError("Every column must have a non-empty name.")
            if len({h.casefold() for h in headers}) != len(headers):
                raise ProfileError("Column names must be unique, ignoring letter case.")
            cols = [_Column(median_limit, rng) for _ in headers]
            rows = 0
            for line_no, row in enumerate(reader, start=2):
                if len(row) != len(headers):
                    raise ProfileError(f"Row {line_no} has {len(row)} fields; expected {len(headers)}.")
                rows += 1
                for col, raw in zip(cols, row):
                    col.add(raw)
    except UnicodeDecodeError as exc:  # raised while reading, not on open()
        raise ProfileError("CSV must be UTF-8 encoded (with or without a BOM).") from exc
    except csv.Error as exc:
        line = reader.line_num if reader else "?"
        raise ProfileError(f"Malformed CSV near line {line}: {exc}") from exc
    except PermissionError as exc:
        raise ProfileError(f"Permission denied reading {source.name}.") from exc

    columns = [c.summary(n, rows) for n, c in zip(headers, cols)]
    return {
        "id": datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S%f"),
        "source": source.name,
        "path": str(source.resolve()),
        "analyzed_at": datetime.now().astimezone().isoformat(timespec="seconds"),
        "rows": rows,
        "column_count": len(headers),
        "quality_score": quality_score(columns),
        "columns": columns,
    }
