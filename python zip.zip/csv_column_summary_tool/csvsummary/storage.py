"""Atomic file writes and JSON analysis history."""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent.parent
HISTORY_FILE = APP_DIR / "data" / "history.json"
MAX_HISTORY = 500


def atomic_write_text(path, content: str) -> None:
    """Write beside the destination, fsync, then atomically replace it."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(content)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


def load_history(path=HISTORY_FILE) -> list[dict]:
    path = Path(path)
    if not path.exists():
        return []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, list) or not all(isinstance(i, dict) for i in data):
            raise ValueError("history must be a list of records")
        return data
    except (json.JSONDecodeError, OSError, ValueError) as exc:
        backup = path.with_suffix(".corrupt")
        try:
            os.replace(path, backup)
            note = f"; the damaged file was kept as {backup.name}"
        except OSError:
            note = ""
        print(f"Warning: history unreadable ({exc}){note}. Starting fresh.")
        return []


def save_history(history: list[dict], path=HISTORY_FILE) -> None:
    atomic_write_text(path, json.dumps(history[-MAX_HISTORY:], indent=2, ensure_ascii=False) + "\n")


def search_history(history, filename="", column="", datatype="") -> list[tuple[dict, list[dict]]]:
    """Case-insensitive search by file name, column name and column type."""
    filename, column, datatype = filename.casefold(), column.casefold(), datatype.casefold()
    if datatype not in ("", "numeric", "text"):
        raise ValueError("Type must be numeric or text.")
    results = []
    for p in history:
        if filename and filename not in p.get("source", "").casefold():
            continue
        cols = [c for c in p.get("columns", [])
                if (not column or column in c.get("name", "").casefold())
                and (not datatype or c.get("type") == datatype)]
        if (column or datatype) and not cols:
            continue
        results.append((p, cols))
    return results
