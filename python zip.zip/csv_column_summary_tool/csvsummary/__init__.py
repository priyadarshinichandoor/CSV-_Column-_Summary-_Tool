"""CSV Column Summary Tool - streaming CSV profiling package."""
__version__ = "2.0.0"
