"""Optional histogram export (needs matplotlib)."""
from __future__ import annotations

import csv
from pathlib import Path


def histogram(profile: dict, column: str, out_dir: Path) -> Path:
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise RuntimeError("Charting needs matplotlib: pip install matplotlib") from exc
    sel = next((c for c in profile["columns"] if c["type"] == "numeric" and c["name"].casefold() == column.casefold()), None)
    if sel is None:
        raise ValueError("Choose a listed numeric column.")
    values = []
    with open(profile["path"], encoding="utf-8-sig", newline="") as f:
        for row in csv.DictReader(f):
            try:
                values.append(float(row[sel["name"]]))
            except (ValueError, TypeError, KeyError):
                pass
    fig = plt.figure(figsize=(8, 4.5))
    plt.hist(values, bins="auto", color="#3268d5", edgecolor="white")
    plt.axvline(sel["mean"], color="#d55", ls="--", label=f"mean {sel['mean']:.2f}")
    plt.axvline(sel["median"], color="#2a2", ls=":", label=f"median {sel['median']:.2f}")
    plt.title(f"{sel['name']} distribution - {profile['source']}")
    plt.xlabel(sel["name"]); plt.ylabel("Rows"); plt.legend(); plt.tight_layout()
    safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in sel["name"])
    out = Path(out_dir) / f"{Path(profile['source']).stem}_{safe}_distribution.png"
    fig.savefig(out, dpi=150); plt.close(fig)
    return out
