"""Command-line (argparse) and interactive menu front ends."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from . import __version__
from .charts import histogram
from .exporters import export_report, fmt
from .profiler import ProfileError, profile_csv
from .storage import APP_DIR, load_history, save_history, search_history


def show_profile(p: dict, out=None) -> None:
    w = lambda s="": print(s, file=out or sys.stdout)
    w(f"\n{p['source']} | {p['rows']:,} rows | {p['column_count']} columns | quality {p['quality_score']}%")
    w("-" * 128)
    w(f"{'COLUMN':<22} {'TYPE':<8} {'MISSING':>8} {'UNIQUE':>8} {'MIN':>10} {'MEDIAN':>10} {'MEAN':>10} {'MAX':>10} {'STD':>10} {'OUTL':>5}")
    w("-" * 128)
    for c in p["columns"]:
        uniq = f">{c['unique']}" if c.get("unique_is_lower_bound") else str(c["unique"])
        stats = [fmt(c.get(k)) if c["type"] == "numeric" else "-" for k in ("min", "median", "mean", "max", "std")]
        w(f"{c['name'][:21]:<22} {c['type']:<8} {c['missing']:>8} {uniq:>8} " + " ".join(f"{s:>10}" for s in stats)
          + f" {c.get('outliers', '-'):>5}")
    if any(c.get("median_is_sampled") for c in p["columns"]):
        w("Note: median/quartiles use a bounded random sample for large columns.")


def ask(prompt: str) -> str:
    return input(prompt).strip().strip('"')


def _export(p: dict, target: str, overwrite=False) -> None:
    try:
        print(f"Report saved: {export_report(p, target, overwrite).resolve()}")
    except FileExistsError as exc:
        if input(f"{exc} Overwrite? [y/N] ").strip().lower() == "y":
            _export(p, target, True)
    except (ValueError, OSError) as exc:
        print(f"Could not write report: {exc}")


def _analyze(history: list[dict]) -> None:
    try:
        p = profile_csv(ask("CSV path (or drag a file here): "))
    except FileNotFoundError as exc:
        print(f"Could not analyze CSV: {exc}"); return
    except (ProfileError, OSError) as exc:
        print(f"Could not analyze CSV: {exc}"); return
    show_profile(p)
    history.append(p)
    try:
        save_history(history); print("Saved to local analysis history.")
    except OSError as exc:
        print(f"Warning: analysis succeeded, but history could not be saved: {exc}")
    if input("Export this report? [y/N] ").strip().lower() == "y":
        target = ask("Output file (.md .txt .csv .json .html): ")
        if target: _export(p, target)


def _history(history: list[dict]) -> None:
    if not history:
        print("No saved analyses yet."); return
    try:
        matches = search_history(history, ask("Filename contains (Enter for any): "),
                                 ask("Column name contains (Enter for any): "),
                                 ask("Column type: numeric, text, or Enter for any: "))
    except ValueError as exc:
        print(exc); return
    if not matches:
        print("No matches."); return
    for i, (p, cols) in enumerate(matches, 1):
        extra = f" | matched: {', '.join(c['name'] for c in cols)}" if cols and len(cols) != len(p['columns']) else ""
        print(f"{i}. {p['source']} | {p['rows']} rows x {p['column_count']} cols | {p['analyzed_at']}{extra}")
    choice = ask("Enter a number to view/export, or Enter to return: ")
    if choice.isdigit() and 1 <= int(choice) <= len(matches):
        p = matches[int(choice) - 1][0]
        show_profile(p)
        if input("Export this report? [y/N] ").strip().lower() == "y":
            target = ask("Output file (.md .txt .csv .json .html): ")
            if target: _export(p, target)


def _chart(history: list[dict]) -> None:
    if not history:
        print("Analyze a CSV first."); return
    p = history[-1]
    numeric = [c["name"] for c in p["columns"] if c["type"] == "numeric"]
    if not numeric:
        print("The latest file has no numeric columns to chart."); return
    print("Numeric columns: " + ", ".join(numeric))
    try:
        print(f"Chart saved: {histogram(p, ask('Column to chart: '), APP_DIR)}")
    except (RuntimeError, ValueError, OSError) as exc:
        print(f"Could not generate chart: {exc}")


def menu() -> None:
    history = load_history()
    actions = {"1": _analyze, "2": _history, "3": _chart}
    while True:
        print("\nCSV COLUMN SUMMARY TOOL\n1. Analyze a CSV\n2. Search analysis history\n3. Export latest chart\n4. Exit")
        choice = ask("Select 1-4: ")
        if choice == "4":
            print("Goodbye!"); return
        actions.get(choice, lambda _h: print("Enter a number from 1 to 4."))(history)


def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="csvsummary", description="Profile CSV files locally.")
    ap.add_argument("csv", nargs="?", help="CSV file to analyze (omit for the interactive menu)")
    ap.add_argument("-o", "--output", help="export report (.md .txt .csv .json .html)")
    ap.add_argument("--force", action="store_true", help="overwrite the output file if it exists")
    ap.add_argument("--no-history", action="store_true", help="do not record this run in history")
    ap.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    return ap


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if not args.csv:
        menu(); return 0
    try:
        p = profile_csv(args.csv)
        show_profile(p)
        if not args.no_history:
            h = load_history(); h.append(p); save_history(h)
        if args.output:
            print(f"Report saved: {export_report(p, args.output, args.force).resolve()}")
    except (FileNotFoundError, FileExistsError, ProfileError, ValueError, OSError) as exc:
        print(f"Error: {exc}", file=sys.stderr); return 1
    return 0
