"""Report exporters (csv, md, txt, json, html) with output-path and formula-injection safety."""
from __future__ import annotations

import csv
import html
import io
import json
from pathlib import Path

from .storage import atomic_write_text

ALLOWED = (".csv", ".md", ".txt", ".json", ".html")
STAT_KEYS = ("min", "q1", "median", "mean", "q3", "max", "std")


def safe_cell(value) -> str:
    """Neutralise spreadsheet formula injection (=, +, -, @) in exported text."""
    text = "" if value is None else str(value)
    return "'" + text if text[:1] in ("=", "+", "-", "@", "\t", "\r") and not _is_number(text) else text


def _is_number(text: str) -> bool:
    try:
        float(text)
        return True
    except ValueError:
        return False


def fmt(n) -> str:
    return "-" if n is None else (f"{n:,.3f}".rstrip("0").rstrip("."))


def validate_output_path(target: str, overwrite: bool = False) -> Path:
    out = Path(target).expanduser()
    if out.suffix.lower() not in ALLOWED:
        raise ValueError(f"Choose one of: {', '.join(ALLOWED)}.")
    if out.is_dir():
        raise ValueError("Output path is a folder; give a file name.")
    if out.is_symlink():
        raise ValueError("Refusing to write through a symbolic link.")
    if out.exists() and not overwrite:
        raise FileExistsError(f"{out.name} already exists.")
    return out


def to_csv(p: dict) -> str:
    buf = io.StringIO(newline="")
    w = csv.writer(buf)
    w.writerow(["column", "type", "missing", "missing_pct", "unique", *STAT_KEYS, "outliers"])
    for c in p["columns"]:
        w.writerow([safe_cell(c["name"]), c["type"], c["missing"], c["missing_pct"], c["unique"],
                    *[c.get(k, "") for k in STAT_KEYS], c.get("outliers", "")])
    return buf.getvalue()


def to_markdown(p: dict) -> str:
    lines = [f"# CSV Summary: {p['source']}",
             f"Rows: {p['rows']:,} | Columns: {p['column_count']} | Data quality: {p['quality_score']}%",
             f"Analyzed: {p['analyzed_at']}", "",
             "| Column | Type | Missing | Unique | Min | Q1 | Median | Mean | Q3 | Max | Std | Outliers |",
             "|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for c in p["columns"]:
        lines.append(f"| {safe_cell(c['name'])} | {c['type']} | {c['missing']} | {c['unique']} | "
                     + " | ".join(fmt(c.get(k)) for k in ("min", "q1", "median", "mean", "q3", "max", "std"))
                     + f" | {c.get('outliers', '-')} |")
    lines += ["", "## Top values (text columns)"]
    for c in p["columns"]:
        if c["type"] == "text" and c["top_values"]:
            lines.append(f"- **{safe_cell(c['name'])}**: " + ", ".join(f"{safe_cell(v)} ({n})" for v, n in c["top_values"]))
    return "\n".join(lines) + "\n"


def to_json(p: dict) -> str:
    return json.dumps(p, indent=2, ensure_ascii=False) + "\n"


def to_html(p: dict) -> str:
    e = html.escape
    rows = "".join(
        f"<tr><td>{e(c['name'])}</td><td>{c['type']}</td><td>{c['missing']}</td><td>{c['unique']}</td>"
        + "".join(f"<td>{fmt(c.get(k))}</td>" for k in ("min", "median", "mean", "max", "std"))
        + f"<td>{c.get('outliers', '-')}</td></tr>" for c in p["columns"])
    return (f"<!doctype html><meta charset='utf-8'><title>{e(p['source'])}</title>"
            "<style>body{font:15px system-ui;margin:2rem}table{border-collapse:collapse}"
            "td,th{border:1px solid #ccd;padding:.4rem .7rem;text-align:right}td:first-child,th:first-child{text-align:left}"
            "th{background:#eef}</style>"
            f"<h1>{e(p['source'])}</h1><p>{p['rows']:,} rows | {p['column_count']} columns | "
            f"data quality {p['quality_score']}%</p><table><tr><th>Column<th>Type<th>Missing<th>Unique"
            f"<th>Min<th>Median<th>Mean<th>Max<th>Std<th>Outliers</tr>{rows}</table>")


RENDERERS = {".csv": to_csv, ".md": to_markdown, ".txt": to_markdown, ".json": to_json, ".html": to_html}


def export_report(p: dict, target: str, overwrite: bool = False) -> Path:
    out = validate_output_path(target, overwrite)
    atomic_write_text(out, RENDERERS[out.suffix.lower()](p))
    return out
