import tempfile, unittest, os
from pathlib import Path
from csvsummary.profiler import profile_csv, ProfileError


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.root = Path(self.tmp.name)
    def tearDown(self): self.tmp.cleanup()
    def csv(self, text, name="data.csv", enc="utf-8"):
        p = self.root / name; p.write_bytes(text.encode(enc)); return p


class StatsTests(Base):
    def test_mean_median_std_quartiles(self):
        c = profile_csv(self.csv("x\n1\n2\n3\n4\n5\n"))["columns"][0]
        self.assertEqual((c["min"], c["max"], c["mean"], c["median"]), (1, 5, 3, 3))
        self.assertAlmostEqual(c["std"], 1.5811388, places=5)
        self.assertEqual((c["q1"], c["q3"]), (2, 4))
    def test_missing_and_pct(self):
        p = profile_csv(self.csv("score,team\n10,Red\n,Blue\n20,Red\n,\n"))
        s, t = p["columns"]
        self.assertEqual((s["missing"], s["missing_pct"], s["mean"]), (2, 50.0, 15))
        self.assertEqual(t["type"], "text"); self.assertEqual(t["top_values"][0], ["Red", 2])
        self.assertEqual(p["quality_score"], 62.5)
    def test_outlier_detection(self):
        c = profile_csv(self.csv("x\n" + "\n".join(["10"] * 20 + ["1000"])))["columns"][0]
        self.assertEqual(c["outliers"], 1)
    def test_mixed_column_is_text(self):
        self.assertEqual(profile_csv(self.csv("x\n1\nabc\n3\n"))["columns"][0]["type"], "text")
    def test_all_missing_column_is_text(self):
        self.assertEqual(profile_csv(self.csv("x,y\n,1\n,2\n"))["columns"][0]["type"], "text")
    def test_non_finite_values_not_numeric(self):
        self.assertEqual(profile_csv(self.csv("x\n1\nnan\ninf\n"))["columns"][0]["type"], "text")
    def test_single_value_std_zero(self):
        self.assertEqual(profile_csv(self.csv("x\n7\n"))["columns"][0]["std"], 0.0)
    def test_header_only_file(self):
        p = profile_csv(self.csv("a,b\n")); self.assertEqual(p["rows"], 0)
    def test_unicode_bom_quotes_and_crlf(self):
        p = profile_csv(self.csv('\ufeffname,score\r\n"A, B",1\r\n', enc="utf-8"))
        self.assertEqual(p["columns"][0]["name"], "name"); self.assertEqual(p["columns"][0]["unique"], 1)


class LargeDataTests(Base):
    def test_median_sampling_bounded_and_flagged(self):
        c = profile_csv(self.csv("x\n" + "\n".join(map(str, range(1000)))), median_limit=50)["columns"][0]
        self.assertTrue(c["median_is_sampled"])
        self.assertAlmostEqual(c["mean"], 499.5)  # mean stays exact
    def test_sampling_is_reproducible(self):
        f = self.csv("x\n" + "\n".join(map(str, range(1000))))
        self.assertEqual(profile_csv(f, 50)["columns"][0]["median"], profile_csv(f, 50)["columns"][0]["median"])
    def test_exact_below_limit(self):
        self.assertFalse(profile_csv(self.csv("x\n1\n2\n3\n"))["columns"][0]["median_is_sampled"])


class ValidationTests(Base):
    def test_duplicate_headers_case_insensitive(self):
        with self.assertRaisesRegex(ProfileError, "unique"): profile_csv(self.csv("Name,name\na,b\n"))
    def test_blank_header(self):
        with self.assertRaisesRegex(ProfileError, "non-empty"): profile_csv(self.csv("a,\n1,2\n"))
    def test_wrong_row_width_reports_line(self):
        with self.assertRaisesRegex(ProfileError, "Row 3"): profile_csv(self.csv("a,b\n1,2\n1\n"))
    def test_empty_file(self):
        with self.assertRaisesRegex(ProfileError, "empty"): profile_csv(self.csv(""))
    def test_non_csv_extension(self):
        with self.assertRaisesRegex(ProfileError, r"\.csv"): profile_csv(self.csv("x\n1\n", "d.txt"))
    def test_missing_file(self):
        with self.assertRaises(FileNotFoundError): profile_csv(self.root / "nope.csv")
    def test_directory_rejected(self):
        with self.assertRaises(FileNotFoundError): profile_csv(self.root)
    def test_non_utf8_rejected(self):
        with self.assertRaisesRegex(ProfileError, "UTF-8"): profile_csv(self.csv("x\n\xe9\n", enc="latin-1"))
    def test_bad_median_limit(self):
        with self.assertRaisesRegex(ProfileError, "positive"): profile_csv(self.csv("x\n1\n"), median_limit=0)
    def test_malformed_quote(self):
        with self.assertRaises(ProfileError): profile_csv(self.csv('a,b\n"x"y,1\n'))
    @unittest.skipUnless(hasattr(os, "symlink"), "symlinks unsupported")
    def test_symlink_rejected(self):
        real = self.csv("x\n1\n"); link = self.root / "link.csv"
        try: os.symlink(real, link)
        except OSError: self.skipTest("no symlink privilege")
        with self.assertRaisesRegex(ProfileError, "Symbolic"): profile_csv(link)


if __name__ == "__main__": unittest.main()
