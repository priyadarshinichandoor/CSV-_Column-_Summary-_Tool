import csv, io, json, tempfile, unittest, contextlib
from pathlib import Path
from csvsummary import exporters as ex
from csvsummary.cli import main as cli_main
from csvsummary.profiler import profile_csv
from csvsummary.storage import atomic_write_text, load_history, save_history, search_history, MAX_HISTORY

SAMPLE = "id,score,note\nA,10,=cmd|' /C calc'!A0\nB,20,hello\nC,,hello\n"


class Base(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.root = Path(self.tmp.name)
        self.src = self.root / "d.csv"; self.src.write_text(SAMPLE, encoding="utf-8")
        self.p = profile_csv(self.src)
    def tearDown(self): self.tmp.cleanup()


class StorageTests(Base):
    def test_round_trip(self):
        h = self.root / "h.json"; save_history([{"source": "a"}], h); self.assertEqual(load_history(h), [{"source": "a"}])
    def test_missing_history_is_empty(self): self.assertEqual(load_history(self.root / "none.json"), [])
    def test_corrupt_history_kept_as_backup(self):
        h = self.root / "h.json"; h.write_text("{broken"); 
        with contextlib.redirect_stdout(io.StringIO()): self.assertEqual(load_history(h), [])
        self.assertTrue((self.root / "h.corrupt").exists())
    def test_wrong_shape_rejected(self):
        h = self.root / "h.json"; h.write_text('{"a":1}')
        with contextlib.redirect_stdout(io.StringIO()): self.assertEqual(load_history(h), [])
    def test_history_capped(self):
        h = self.root / "h.json"; save_history([{"i": i} for i in range(MAX_HISTORY + 5)], h)
        self.assertEqual(len(load_history(h)), MAX_HISTORY)
    def test_atomic_write_leaves_no_temp_files(self):
        atomic_write_text(self.root / "o.txt", "hi"); self.assertEqual([f.name for f in self.root.glob(".*tmp")], [])
    def test_search_filters(self):
        hist = [self.p]
        self.assertEqual(len(search_history(hist, "D.CSV")), 1)
        self.assertEqual(len(search_history(hist, column="SCORE", datatype="numeric")), 1)
        self.assertEqual(search_history(hist, column="id", datatype="numeric"), [])
        with self.assertRaises(ValueError): search_history(hist, datatype="date")


class ExporterTests(Base):
    def test_formula_injection_neutralised(self):
        self.assertTrue(ex.safe_cell("=1+1").startswith("'")); self.assertEqual(ex.safe_cell("-5"), "-5")
        self.assertEqual(ex.safe_cell("hello"), "hello")
    def test_csv_export_parses(self):
        rows = list(csv.reader(io.StringIO(ex.to_csv(self.p)))); self.assertEqual(len(rows), 4); self.assertEqual(rows[0][0], "column")
    def test_markdown_has_quality_and_table(self):
        md = ex.to_markdown(self.p); self.assertIn("Data quality", md); self.assertIn("| score | numeric |", md)
    def test_json_round_trip(self): self.assertEqual(json.loads(ex.to_json(self.p))["rows"], 3)
    def test_html_escapes(self):
        p = dict(self.p); p["source"] = "<script>x</script>.csv"; self.assertNotIn("<script>", ex.to_html(p))
    def test_export_writes_and_refuses_overwrite(self):
        out = self.root / "r.md"; ex.export_report(self.p, str(out)); self.assertTrue(out.exists())
        with self.assertRaises(FileExistsError): ex.export_report(self.p, str(out))
        ex.export_report(self.p, str(out), overwrite=True)
    def test_bad_extension_and_folder(self):
        with self.assertRaises(ValueError): ex.export_report(self.p, str(self.root / "r.exe"))
        with self.assertRaises(ValueError): ex.validate_output_path(str(self.root), False)


class CliTests(Base):
    def run_cli(self, *a):
        out, err = io.StringIO(), io.StringIO()
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err): code = cli_main(list(a))
        return code, out.getvalue(), err.getvalue()
    def test_analyze_and_export(self):
        o = self.root / "r.html"; code, out, _ = self.run_cli(str(self.src), "--no-history", "-o", str(o))
        self.assertEqual(code, 0); self.assertIn("3 rows", out); self.assertTrue(o.exists())
    def test_missing_file_exit_code(self):
        code, _, err = self.run_cli(str(self.root / "no.csv"), "--no-history"); self.assertEqual(code, 1); self.assertIn("not found", err)
    def test_bad_csv_exit_code(self):
        bad = self.root / "b.csv"; bad.write_text("a,b\n1\n"); self.assertEqual(self.run_cli(str(bad), "--no-history")[0], 1)


if __name__ == "__main__": unittest.main()
