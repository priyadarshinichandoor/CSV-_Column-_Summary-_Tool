"""CSV Column Summary Tool entry point: `python main.py` (menu) or `python main.py data.csv -o report.html`."""
import sys
from csvsummary.cli import main

if __name__ == "__main__":
    sys.exit(main())
